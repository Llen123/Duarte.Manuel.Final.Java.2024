/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package manuelduarte122final;

/**
 *
 * @author llen0
 */

import PersonaClases.Persona;
import PersonaClases.Estudiante;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.List;
import excepciones.PersistenciaException;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import enums.EstadoAcademico;


public class Persistencia {

    public static void guardar(String ruta, List<? extends Persona> lista) {
    try (ObjectOutputStream oos =
                 new ObjectOutputStream(new FileOutputStream(ruta))) {

        oos.writeObject(lista);

    } catch (IOException e) {
        throw new PersistenciaException(
                "Error al guardar los datos en " + ruta, e);
    }
}

    @SuppressWarnings("unchecked")
    public static List<Persona> cargar(String ruta) {
    try (ObjectInputStream ois =
                 new ObjectInputStream(new FileInputStream(ruta))) {

        return (List<Persona>) ois.readObject();

    } catch (Exception e) {
        throw new PersistenciaException(
                "Error al cargar los datos desde " + ruta, e);
    }
}
    public static void guardarCSV(String ruta, List<Estudiante> lista) {

    try (PrintWriter pw = new PrintWriter(new FileWriter(ruta))) {

        // Encabezado
        pw.println("ID,Nombre,Edad,Carrera,Promedio,Estado");

        for (Estudiante e : lista) {
            pw.println(
                    e.getId() + "," +
                    e.getNombre() + "," +
                    e.getEdad() + "," +
                    e.getCarrera() + "," +
                    e.getPromedio() + "," +
                    e.getEstadoAcademico()
            );
        }

    } catch (IOException e) {
        throw new PersistenciaException(
                "Error al guardar CSV en " + ruta, e);
    }
}
    public static List<Estudiante> cargarCSV(String ruta) {

    List<Estudiante> lista = new ArrayList<>();

    try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {

        String linea;
        br.readLine(); // saltar encabezado

        while ((linea = br.readLine()) != null) {

            String[] datos = linea.split(",");

            int id = Integer.parseInt(datos[0]);
            String nombre = datos[1];
            int edad = Integer.parseInt(datos[2]);
            String carrera = datos[3];
            double promedio = Double.parseDouble(datos[4]);
            EstadoAcademico estado =
                    EstadoAcademico.valueOf(datos[5]);

            Estudiante e = new Estudiante(
                    id, nombre, edad, carrera, promedio, estado
            );


            lista.add(e);
        }

    } catch (IOException e) {
        throw new PersistenciaException(
                "Error al cargar CSV desde " + ruta, e);
    }

    return lista;
}
    public static void guardarJSON(String ruta, List<Estudiante> lista) {

    try (PrintWriter pw = new PrintWriter(new FileWriter(ruta))) {

        pw.println("[");  // inicio del array JSON

        for (int i = 0; i < lista.size(); i++) {

            Estudiante e = lista.get(i);

            pw.println("  {");
            pw.println("    \"id\": " + e.getId() + ",");
            pw.println("    \"nombre\": \"" + e.getNombre() + "\",");
            pw.println("    \"edad\": " + e.getEdad() + ",");
            pw.println("    \"carrera\": \"" + e.getCarrera() + "\",");
            pw.println("    \"promedio\": " + e.getPromedio() + ",");
            pw.println("    \"estadoAcademico\": \"" + e.getEstadoAcademico() + "\"");
            pw.print("  }");

            if (i < lista.size() - 1) {
                pw.println(",");
            } else {
                pw.println();
            }
        }

        pw.println("]"); // fin del array

    } catch (IOException e) {
        throw new PersistenciaException(
                "Error al guardar JSON en " + ruta, e);
    }
}
    public static List<Estudiante> cargarJSON(String ruta) {

    List<Estudiante> lista = new ArrayList<>();

    try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {

        String linea;
        int id = 0;
        String nombre = "";
        int edad = 0;
        String carrera = "";
        double promedio = 0;
        EstadoAcademico estado = null;

        while ((linea = br.readLine()) != null) {

            linea = linea.trim();

            if (linea.startsWith("\"id\"")) {
                id = Integer.parseInt(linea.split(":")[1].replace(",", "").trim());
            }

            if (linea.startsWith("\"nombre\"")) {
                nombre = linea.split(":")[1].replace("\"", "").replace(",", "").trim();
            }

            if (linea.startsWith("\"edad\"")) {
                edad = Integer.parseInt(linea.split(":")[1].replace(",", "").trim());
            }

            if (linea.startsWith("\"carrera\"")) {
                carrera = linea.split(":")[1].replace("\"", "").replace(",", "").trim();
            }

            if (linea.startsWith("\"promedio\"")) {
                promedio = Double.parseDouble(linea.split(":")[1].replace(",", "").trim());
            }

            if (linea.startsWith("\"estadoAcademico\"")) {
                String estadoStr = linea.split(":")[1]
                        .replace("\"", "")
                        .trim();

                estado = EstadoAcademico.valueOf(estadoStr);

                // Cuando llegamos al último atributo, creamos el objeto
                Estudiante e = new Estudiante(
                        id, nombre, edad, carrera, promedio, estado
                );

                lista.add(e);
            }
        }

    } catch (IOException e) {
        throw new PersistenciaException(
                "Error al cargar JSON desde " + ruta, e);
    }

    return lista;
}
    public static void exportarTXT(String ruta,
                               List<? extends Persona> lista,
                               String encabezado) {

    try (PrintWriter pw = new PrintWriter(new FileWriter(ruta))) {

        pw.println(encabezado);
        pw.println("====================================");
        pw.println();

        for (Persona p : lista) {

            if (p instanceof Estudiante e) {

                pw.println("ID: " + e.getId());
                pw.println("Nombre: " + e.getNombre());
                pw.println("Edad: " + e.getEdad());
                pw.println("Carrera: " + e.getCarrera());
                pw.println("Promedio: " + e.getPromedio());
                pw.println("Estado: " + e.getEstadoAcademico());
                pw.println("------------------------------------");
                pw.println();
            }
        }

    } catch (IOException e) {
        throw new PersistenciaException(
                "Error al exportar TXT en " + ruta, e);
    }
}



}

