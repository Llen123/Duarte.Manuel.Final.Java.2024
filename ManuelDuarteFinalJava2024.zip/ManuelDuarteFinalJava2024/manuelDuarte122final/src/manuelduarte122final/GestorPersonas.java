/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package manuelduarte122final;

/**
 *
 * @author llen0
 */
import PersonaClases.Persona;
import PersonaClases.Estudiante;
import PersonaClases.EstudianteBecado;
import PersonaClases.EstudianteAyudante;
import interfaces.CRUD;
import interfaces.Remunerado;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import excepciones.EntidadNoEncontradaException;
import excepciones.OperacionNoPermitidaException;
import java.util.Comparator;



public class GestorPersonas<T extends Persona> implements CRUD<T> {

    private List<T> lista;

    public GestorPersonas() {
        this.lista = new ArrayList<>();
    }

    @Override
    public void crear(T entidad) {
        if (lista.stream().anyMatch(e -> e.getId() == entidad.getId())) {
            throw new OperacionNoPermitidaException(
                "Ya existe una entidad con ID " + entidad.getId());
    }
        lista.add(entidad);
}


    @Override
    public T leer(int id) {
        return lista.stream()
                .filter(e -> e.getId() == id)
                .findFirst()
                .orElseThrow(() ->
                        new EntidadNoEncontradaException("Entidad con ID " + id + " no encontrada"));
    }

    @Override
    public void actualizar(int id, T nuevaEntidad) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getId() == id) {
                lista.set(i, nuevaEntidad);
                return;
            }
        }
        throw new EntidadNoEncontradaException("No se pudo actualizar. ID " + id + " inexistente.");
    }

    @Override
    public void eliminar(int id) {
        Iterator<T> iterator = lista.iterator();

        while (iterator.hasNext()) {
            if (iterator.next().getId() == id) {
                iterator.remove();
                return;
            }
        }

        throw new EntidadNoEncontradaException("No se pudo eliminar. ID " + id + " inexistente.");
    }

        public List<T> getLista() {
        return new ArrayList<>(lista);
    }

        public void ordenarNatural() {
        lista.sort(null);
    }

        public void ordenar(Comparator<T> comparator) {
        lista.sort(comparator);
    }


    public void aplicarAccionAyudantes(Consumer<EstudianteAyudante> accion) {
    for (T persona : lista) {
        if (persona instanceof EstudianteAyudante ayudante) {
            accion.accept(ayudante);
        }
    }
}
   
    

    public void mostrarTodas(List<? extends Persona> lista) {
    for (Persona p : lista) {
        System.out.println(p.mostrarInformacion());
    }
}
    public void agregarGenerico(List<? super Estudiante> lista, Estudiante estudiante) {
    lista.add(estudiante);
}
    public Iterator<T> iteratorPersonalizado() {
    return new GestorIterator();
}

    private class GestorIterator implements Iterator<T> {
    private int posicion = 0;

    @Override
    public boolean hasNext() {
        return posicion < lista.size();
    }

    @Override
    public T next() {
        if (!hasNext()) {
            throw new java.util.NoSuchElementException("No hay más elementos");
        }
        return lista.get(posicion++);
    }
    
}
    public List<T> filtrar(String patron) {

    String regex = patron.replace("*", ".*").toLowerCase();
    List<T> resultado = new ArrayList<>();

    for (T entidad : lista) {

        // Convertimos todos los campos a texto
        String id = String.valueOf(entidad.getId()).toLowerCase();
        String nombre = entidad.getNombre().toLowerCase();
        String edad = String.valueOf(entidad.getEdad()).toLowerCase();

        if (id.matches(regex) || nombre.matches(regex) || edad.matches(regex)) {
            resultado.add(entidad);
            continue;
        }

        if (entidad instanceof Estudiante e) {

            String carrera = e.getCarrera().toLowerCase();
            String promedio = String.valueOf(e.getPromedio()).toLowerCase();
            String estado = e.getEstadoAcademico().toString().toLowerCase();

            if (carrera.matches(regex) ||
                promedio.matches(regex) ||
                estado.matches(regex)) {

                resultado.add(entidad);
                continue;
            }
        }

        if (entidad instanceof EstudianteBecado b) {

            String porcentaje = String.valueOf(b.getPorcentajeBeca()).toLowerCase();
            String tipoBeca = b.getTipoBeca().toString().toLowerCase();

            if (porcentaje.matches(regex) ||
                tipoBeca.matches(regex)) {

                resultado.add(entidad);
                continue;
            }
        }

        if (entidad instanceof EstudianteAyudante a) {

            String materia = a.getMateriaAsignada().toLowerCase();
            String horas = String.valueOf(a.getHorasSemanales()).toLowerCase();
            String valorHora = String.valueOf(a.getValorHora()).toLowerCase();

            if (materia.matches(regex) ||
                horas.matches(regex) ||
                valorHora.matches(regex)) {

                resultado.add(entidad);
            }
        }
    }

    return resultado;
    }
    public void setLista(List<? extends T> nuevaLista) {
    this.lista.clear();
    this.lista.addAll(nuevaLista);
}

}




