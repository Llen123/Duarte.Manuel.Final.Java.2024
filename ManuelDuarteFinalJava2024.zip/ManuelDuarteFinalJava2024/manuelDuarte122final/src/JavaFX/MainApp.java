package JavaFX;

import PersonaClases.Persona;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import manuelduarte122final.GestorPersonas;

public class MainApp extends Application {

    private final GestorPersonas<Persona> gestor = new GestorPersonas<>();

    @Override
    public void start(Stage stage) {

        VistaFormulario vistaFormulario = new VistaFormulario();
        VistaTabla vistaTabla = new VistaTabla();

        ControladorEventos controlador = new ControladorEventos(
                gestor,
                vistaFormulario,
                vistaTabla,
                stage
        );

        VistaLayout layout = new VistaLayout(
                vistaFormulario,
                vistaTabla
        );

        Scene scene = new Scene(layout.getRoot(), 1280, 720);
        scene.getStylesheets().add(
        getClass().getResource("/JavaFX/estilo.css").toExternalForm()
        );    
        stage.setScene(scene);
        stage.setTitle("Sistema Gestión Estudiantes");
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}