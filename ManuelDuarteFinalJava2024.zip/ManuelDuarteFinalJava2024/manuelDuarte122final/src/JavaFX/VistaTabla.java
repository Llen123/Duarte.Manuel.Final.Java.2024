package JavaFX;

import PersonaClases.Persona;
import PersonaClases.Estudiante;
import PersonaClases.EstudianteBecado;
import PersonaClases.EstudianteAyudante;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.util.List;

public class VistaTabla {

    private TableView<Persona> tabla = new TableView<>();
    private ObservableList<Persona> datos = FXCollections.observableArrayList();

    public VistaTabla() {
        crearColumnas();
        tabla.setItems(datos);
    }

    private void crearColumnas() {
        TableColumn<Persona, String> colTipo = new TableColumn<>("Tipo");

        colTipo.setCellValueFactory(data -> {

            Persona p = data.getValue();

            if (p instanceof EstudianteBecado) {
                return new javafx.beans.property.SimpleStringProperty("Becado");
            } 
            else if (p instanceof EstudianteAyudante) {
                return new javafx.beans.property.SimpleStringProperty("Ayudante");
            } 
            else if (p instanceof Estudiante) {
                return new javafx.beans.property.SimpleStringProperty("Estudiante");
            }

            return new javafx.beans.property.SimpleStringProperty("—");
        });

        TableColumn<Persona, Integer> colId = new TableColumn<>("ID");
        colId.setCellValueFactory(data ->
                new javafx.beans.property.SimpleIntegerProperty(
                        data.getValue().getId()).asObject());

        TableColumn<Persona, String> colNombre = new TableColumn<>("Nombre");
        colNombre.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(
                        data.getValue().getNombre()));

        TableColumn<Persona, Integer> colEdad = new TableColumn<>("Edad");
        colEdad.setCellValueFactory(data ->
                new javafx.beans.property.SimpleIntegerProperty(
                        data.getValue().getEdad()).asObject());

        // ----------- ESTUDIANTE -----------

        TableColumn<Persona, String> colCarrera = new TableColumn<>("Carrera");
        colCarrera.setCellValueFactory(data -> {
            if (data.getValue() instanceof Estudiante e) {
                return new javafx.beans.property.SimpleStringProperty(e.getCarrera());
            }
            return new javafx.beans.property.SimpleStringProperty("—");
        });

        TableColumn<Persona, String> colPromedio = new TableColumn<>("Promedio");
        colPromedio.setCellValueFactory(data -> {
            if (data.getValue() instanceof Estudiante e) {
                return new javafx.beans.property.SimpleStringProperty(
                        String.valueOf(e.getPromedio()));
            }
            return new javafx.beans.property.SimpleStringProperty("—");
        });

        TableColumn<Persona, String> colEstado = new TableColumn<>("Estado");
        colEstado.setCellValueFactory(data -> {
            if (data.getValue() instanceof Estudiante e) {
                return new javafx.beans.property.SimpleStringProperty(
                        e.getEstadoAcademico().toString());
            }
            return new javafx.beans.property.SimpleStringProperty("—");
        });

        // ----------- BECADO -----------

        TableColumn<Persona, String> colPorcentaje = new TableColumn<>("% Beca");
        colPorcentaje.setCellValueFactory(data -> {
            if (data.getValue() instanceof EstudianteBecado b) {
                return new javafx.beans.property.SimpleStringProperty(
                        String.valueOf(b.getPorcentajeBeca()));
            }
            return new javafx.beans.property.SimpleStringProperty("—");
        });

        TableColumn<Persona, String> colTipoBeca = new TableColumn<>("Tipo Beca");
        colTipoBeca.setCellValueFactory(data -> {
            if (data.getValue() instanceof EstudianteBecado b) {
                return new javafx.beans.property.SimpleStringProperty(
                        b.getTipoBeca().toString());
            }
            return new javafx.beans.property.SimpleStringProperty("—");
        });

        // ----------- AYUDANTE -----------

        TableColumn<Persona, String> colMateria = new TableColumn<>("Materia");
        colMateria.setCellValueFactory(data -> {
            if (data.getValue() instanceof EstudianteAyudante a) {
                return new javafx.beans.property.SimpleStringProperty(
                        a.getMateriaAsignada());
            }
            return new javafx.beans.property.SimpleStringProperty("—");
        });

        TableColumn<Persona, String> colHoras = new TableColumn<>("Horas");
        colHoras.setCellValueFactory(data -> {
            if (data.getValue() instanceof EstudianteAyudante a) {
                return new javafx.beans.property.SimpleStringProperty(
                        String.valueOf(a.getHorasSemanales()));
            }
            return new javafx.beans.property.SimpleStringProperty("—");
        });

        TableColumn<Persona, String> colValorHora = new TableColumn<>("Valor Hora");
        colValorHora.setCellValueFactory(data -> {
            if (data.getValue() instanceof EstudianteAyudante a) {
                return new javafx.beans.property.SimpleStringProperty(
                        String.format("%.2f", a.getValorHora()));
            }
            return new javafx.beans.property.SimpleStringProperty("—");
        });

        tabla.getColumns().addAll(
                colId, colNombre, colEdad,colTipo,
                colCarrera, colPromedio, colEstado,
                colPorcentaje, colTipoBeca,
                colMateria, colHoras, colValorHora
        );
    }

    // ==========================
    // MÉTODOS PÚBLICOS
    // ==========================

    public TableView<Persona> getTabla() {
        return tabla;
    }

    public void actualizarTabla(List<Persona> lista) {
        datos.setAll(lista);
    }

    public Persona getSeleccionada() {
        return tabla.getSelectionModel().getSelectedItem();
    }

    public ObservableList<Persona> getDatos() {
        return datos;
    }
}