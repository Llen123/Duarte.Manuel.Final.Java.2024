package JavaFX;

import enums.EstadoAcademico;
import enums.TipoBeca;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

public class VistaFormulario {

    // Campos generales
    private TextField txtId = new TextField();
    private TextField txtNombre = new TextField();
    private TextField txtEdad = new TextField();
    private TextField txtCarrera = new TextField();
    private TextField txtPromedio = new TextField();

    // Becado
    private TextField txtPorcentaje = new TextField();
    private ComboBox<TipoBeca> cbBeca = new ComboBox<>();

    // Ayudante
    private TextField txtMateria = new TextField();
    private TextField txtHoras = new TextField();
    private TextField txtValorHora = new TextField();

    // Combos
    private ComboBox<EstadoAcademico> cbEstado = new ComboBox<>();
    private ComboBox<String> cbTipo = new ComboBox<>();

    // Buscar
    private TextField txtBuscar = new TextField();

    // Botones
    private Button btnAgregar = new Button("Agregar");
    private Button btnEliminar = new Button("Eliminar");
    private Button btnOrdenarId = new Button("Ordenar por ID");
    private Button btnOrdenarNombre = new Button("Ordenar por Nombre");
    private Button btnActualizar = new Button("Actualizar");
    private Button btnFiltrar = new Button("Filtrar");
    private Button btnMostrarTodos = new Button("Mostrar Todos");
    private Button btnAumentarPago = new Button("Aumentar 10% Pago Ayudantes");

    // Menú guardado
    private MenuButton btnGuardado = new MenuButton("Guardado");
    private MenuItem itemSerializar = new MenuItem("Serializar (.dat)");
    private MenuItem itemDeserializar = new MenuItem("Deserializar (.dat)");
    private MenuItem itemGuardarCSV = new MenuItem("Guardar CSV");
    private MenuItem itemCargarCSV = new MenuItem("Cargar CSV");
    private MenuItem itemGuardarJSON = new MenuItem("Guardar JSON");
    private MenuItem itemCargarJSON = new MenuItem("Cargar JSON");
    private MenuItem itemExportarTXT = new MenuItem("Exportar TXT");

    private VBox root;

    public VistaFormulario() {

        // Cargar enums
        cbEstado.getItems().addAll(EstadoAcademico.values());
        cbBeca.getItems().addAll(TipoBeca.values());
        cbTipo.getItems().addAll("Estudiante", "Becado", "Ayudante");

        txtBuscar.setPromptText("Buscar por nombre (* como wildcard)");

        // Deshabilitar campos específicos al inicio
        txtPorcentaje.setDisable(true);
        cbBeca.setDisable(true);
        txtMateria.setDisable(true);
        txtHoras.setDisable(true);
        txtValorHora.setDisable(true);

        btnGuardado.getItems().addAll(
                itemSerializar,
                itemDeserializar,
                itemGuardarCSV,
                itemCargarCSV,
                itemGuardarJSON,
                itemCargarJSON,
                itemExportarTXT
        );

        root = new VBox(5,
                new Label("ID"), txtId,
                new Label("Nombre"), txtNombre,
                new Label("Edad"), txtEdad,
                new Label("Carrera"), txtCarrera,
                new Label("Promedio"), txtPromedio,
                new Label("Estado"), cbEstado,
                new Label("Tipo"), cbTipo,

                new Label("Porcentaje Beca"), txtPorcentaje,
                new Label("Tipo Beca"), cbBeca,

                new Label("Materia Ayudante"), txtMateria,
                new Label("Horas Semanales"), txtHoras,
                new Label("Valor Hora"), txtValorHora,

                new Label("Buscar"),
                txtBuscar,
                btnFiltrar,
                btnMostrarTodos,

                btnAgregar,
                btnEliminar,
                btnOrdenarId,
                btnOrdenarNombre,
                btnActualizar,
                btnAumentarPago,
                btnGuardado
        );
    }

    // =======================
    // GETTERS
    // =======================

    public VBox getRoot() { return root; }

    public TextField getTxtId() { return txtId; }
    public TextField getTxtNombre() { return txtNombre; }
    public TextField getTxtEdad() { return txtEdad; }
    public TextField getTxtCarrera() { return txtCarrera; }
    public TextField getTxtPromedio() { return txtPromedio; }
    public TextField getTxtPorcentaje() { return txtPorcentaje; }
    public TextField getTxtMateria() { return txtMateria; }
    public TextField getTxtHoras() { return txtHoras; }
    public TextField getTxtValorHora() { return txtValorHora; }
    public TextField getTxtBuscar() { return txtBuscar; }

    public ComboBox<EstadoAcademico> getCbEstado() { return cbEstado; }
    public ComboBox<TipoBeca> getCbBeca() { return cbBeca; }
    public ComboBox<String> getCbTipo() { return cbTipo; }

    public Button getBtnAgregar() { return btnAgregar; }
    public Button getBtnEliminar() { return btnEliminar; }
    public Button getBtnOrdenarId() { return btnOrdenarId; }
    public Button getBtnOrdenarNombre() { return btnOrdenarNombre; }
    public Button getBtnActualizar() { return btnActualizar; }
    public Button getBtnFiltrar() { return btnFiltrar; }
    public Button getBtnMostrarTodos() { return btnMostrarTodos; }
    public Button getBtnAumentarPago() { return btnAumentarPago; }

    public MenuButton getBtnGuardado() { return btnGuardado; }
    public MenuItem getItemSerializar() { return itemSerializar; }
    public MenuItem getItemDeserializar() { return itemDeserializar; }
    public MenuItem getItemGuardarCSV() { return itemGuardarCSV; }
    public MenuItem getItemCargarCSV() { return itemCargarCSV; }
    public MenuItem getItemGuardarJSON() { return itemGuardarJSON; }
    public MenuItem getItemCargarJSON() { return itemCargarJSON; }
    public MenuItem getItemExportarTXT() { return itemExportarTXT; }
}