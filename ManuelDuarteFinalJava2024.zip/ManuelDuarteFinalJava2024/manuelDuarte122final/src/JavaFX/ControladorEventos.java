package JavaFX;

import PersonaClases.*;
import Comparadores.ComparadorPorId;
import Comparadores.ComparadorPorNombre;
import enums.EstadoAcademico;
import enums.TipoBeca;
import javafx.scene.control.Alert;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import manuelduarte122final.GestorPersonas;
import manuelduarte122final.Persistencia;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ControladorEventos {

    private final GestorPersonas<Persona> gestor;
    private final VistaFormulario vista;
    private final VistaTabla vistaTabla;
    private final Stage stage;
    
    

    public ControladorEventos(GestorPersonas<Persona> gestor,
                               VistaFormulario vista,
                               VistaTabla vistaTabla,
                               Stage stage) {

        this.gestor = gestor;
        this.vista = vista;
        this.vistaTabla = vistaTabla;
        this.stage = stage;

        configurarEventos();
    }

    private void configurarEventos() {
        vista.getItemGuardarCSV().setOnAction(e -> {

    FileChooser fileChooser = new FileChooser();
    fileChooser.setTitle("Guardar CSV");
    fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Archivo CSV (*.csv)", "*.csv")
    );

    File archivo = fileChooser.showSaveDialog(stage);

    if (archivo != null) {

        List<Estudiante> estudiantes = new ArrayList<>();

        for (Persona p : gestor.getLista()) {
            if (p instanceof Estudiante est) {
                estudiantes.add(est);
            }
        }

        Persistencia.guardarCSV(archivo.getAbsolutePath(), estudiantes);
    }
});
        vista.getItemCargarCSV().setOnAction(e -> {

    FileChooser fileChooser = new FileChooser();
    fileChooser.setTitle("Abrir CSV");
    fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Archivo CSV (*.csv)", "*.csv")
    );

    File archivo = fileChooser.showOpenDialog(stage);

    if (archivo != null) {

        List<Estudiante> lista = Persistencia.cargarCSV(archivo.getAbsolutePath());
        gestor.setLista(lista);
        actualizarTabla();
    }
});
        vista.getItemGuardarJSON().setOnAction(e -> {

    FileChooser fileChooser = new FileChooser();
    fileChooser.setTitle("Guardar archivo JSON");
    fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Archivo JSON (*.json)", "*.json")
    );

    File archivo = fileChooser.showSaveDialog(stage);

    if (archivo != null) {

        List<Estudiante> estudiantes = new ArrayList<>();

        for (Persona p : gestor.getLista()) {
            if (p instanceof Estudiante est) {
                estudiantes.add(est);
            }
        }

        Persistencia.guardarJSON(archivo.getAbsolutePath(), estudiantes);
    }
}); 
        vista.getItemCargarJSON().setOnAction(e -> {

    FileChooser fileChooser = new FileChooser();
    fileChooser.setTitle("Abrir archivo JSON");
    fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Archivo JSON (*.json)", "*.json")
    );

    File archivo = fileChooser.showOpenDialog(stage);

    if (archivo != null) {

        List<Estudiante> lista = Persistencia.cargarJSON(archivo.getAbsolutePath());
        gestor.setLista(lista);
        actualizarTabla();
    }
});
        vista.getItemExportarTXT().setOnAction(e -> {

    FileChooser fileChooser = new FileChooser();
    fileChooser.setTitle("Exportar reporte TXT");
    fileChooser.getExtensionFilters().add(
            new FileChooser.ExtensionFilter("Archivo TXT (*.txt)", "*.txt")
    );

    File archivo = fileChooser.showSaveDialog(stage);

    if (archivo != null) {

        Persistencia.exportarTXT(
                archivo.getAbsolutePath(),
                gestor.getLista(),
                "REPORTE DE ESTUDIANTES"
        );
    }
});

        // ===============================
        // HABILITAR CAMPOS SEGÚN TIPO
        // ===============================

        vista.getCbTipo().setOnAction(e -> {

            String tipo = vista.getCbTipo().getValue();

            vista.getTxtPorcentaje().setDisable(true);
            vista.getCbBeca().setDisable(true);
            vista.getTxtMateria().setDisable(true);
            vista.getTxtHoras().setDisable(true);
            vista.getTxtValorHora().setDisable(true);

            if ("Becado".equals(tipo)) {
                vista.getTxtPorcentaje().setDisable(false);
                vista.getCbBeca().setDisable(false);
            } else if ("Ayudante".equals(tipo)) {
                vista.getTxtMateria().setDisable(false);
                vista.getTxtHoras().setDisable(false);
                vista.getTxtValorHora().setDisable(false);
            }
        });

        // ===============================
        // AGREGAR
        // ===============================

        vista.getBtnAgregar().setOnAction(e -> {
            try {

                Persona p = construirPersonaDesdeFormulario();
                gestor.crear(p);
                actualizarTabla();

            } catch (Exception ex) {
                mostrarAlerta(ex.getMessage());
            }
        });

        // ===============================
        // ELIMINAR
        // ===============================

        vista.getBtnEliminar().setOnAction(e -> {
            Persona seleccionada = vistaTabla.getSeleccionada();
            if (seleccionada != null) {
                try {
                    gestor.eliminar(seleccionada.getId());
                    actualizarTabla();
                } catch (Exception ex) {
                    mostrarAlerta(ex.getMessage());
                }
            }
        });

        // ===============================
        // ORDENAR
        // ===============================

        vista.getBtnOrdenarId().setOnAction(e -> {
            gestor.ordenar(new ComparadorPorId());
            actualizarTabla();
        });

        vista.getBtnOrdenarNombre().setOnAction(e -> {
            gestor.ordenar(new ComparadorPorNombre());
            actualizarTabla();
        });

        // ===============================
        // ACTUALIZAR
        // ===============================

        vista.getBtnActualizar().setOnAction(e -> {
            try {

                Persona seleccionada = vistaTabla.getSeleccionada();
                if (seleccionada == null) {
                    mostrarAlerta("Seleccione una entidad para actualizar");
                    return;
                }

                Persona nueva = construirPersonaDesdeFormulario();
                gestor.actualizar(seleccionada.getId(), nueva);
                actualizarTabla();

            } catch (Exception ex) {
                mostrarAlerta(ex.getMessage());
            }
        });

        // ===============================
        // FILTRAR
        // ===============================

        vista.getBtnFiltrar().setOnAction(e -> {

            String patron = vista.getTxtBuscar().getText();

            if (patron == null || patron.isEmpty()) {
                mostrarAlerta("Ingrese un patrón de búsqueda");
                return;
            }

            vistaTabla.getDatos().setAll(gestor.filtrar(patron));
        });

        vista.getBtnMostrarTodos().setOnAction(e -> {
            actualizarTabla();
            vista.getTxtBuscar().clear();
        });

        // ===============================
        // AUMENTAR 10% PAGO AYUDANTES
        // ===============================

        vista.getBtnAumentarPago().setOnAction(e -> {

            gestor.aplicarAccionAyudantes(a -> {
                double nuevoValor = a.getValorHora() * 1.10;
                a.actualizarPago(nuevoValor);
            });

            actualizarTabla();
        });

        // ===============================
        // PERSISTENCIA
        // ===============================

        vista.getItemSerializar().setOnAction(e -> {

            FileChooser fc = new FileChooser();
            fc.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("Archivo DAT (*.dat)", "*.dat")
            );

            File archivo = fc.showSaveDialog(stage);

            if (archivo != null) {
                Persistencia.guardar(archivo.getAbsolutePath(), gestor.getLista());
            }
        });

        vista.getItemDeserializar().setOnAction(e -> {

            FileChooser fc = new FileChooser();
            fc.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("Archivo DAT (*.dat)", "*.dat")
            );

            File archivo = fc.showOpenDialog(stage);

            if (archivo != null) {
                List<Persona> lista = Persistencia.cargar(archivo.getAbsolutePath());
                gestor.setLista(lista);
                actualizarTabla();
            }
        });

        // ===============================
        // LISTENER TABLA
        // ===============================

        vistaTabla.getTabla().getSelectionModel()
                .selectedItemProperty()
                .addListener((obs, oldSel, sel) -> {

            if (sel == null) return;

            vista.getTxtId().setText(String.valueOf(sel.getId()));
            vista.getTxtNombre().setText(sel.getNombre());
            vista.getTxtEdad().setText(String.valueOf(sel.getEdad()));

            if (sel instanceof Estudiante e) {
                vista.getTxtCarrera().setText(e.getCarrera());
                vista.getTxtPromedio().setText(String.valueOf(e.getPromedio()));
                vista.getCbEstado().setValue(e.getEstadoAcademico());
            }

            if (sel instanceof EstudianteBecado b) {
                vista.getCbTipo().setValue("Becado");
                vista.getTxtPorcentaje().setText(String.valueOf(b.getPorcentajeBeca()));
                vista.getCbBeca().setValue(b.getTipoBeca());
            } else if (sel instanceof EstudianteAyudante a) {
                vista.getCbTipo().setValue("Ayudante");
                vista.getTxtMateria().setText(a.getMateriaAsignada());
                vista.getTxtHoras().setText(String.valueOf(a.getHorasSemanales()));
                vista.getTxtValorHora().setText(String.format("%.2f", a.getValorHora()));
            } else {
                vista.getCbTipo().setValue("Estudiante");
            }   
        });
    }

    // =======================================
    // MÉTODO AUXILIAR PARA CREAR PERSONA
    // =======================================

    private Persona construirPersonaDesdeFormulario() {

    // ===============================
    // VALIDACIONES GENERALES
    // ===============================

    String idStr = vista.getTxtId().getText();
    String nombre = vista.getTxtNombre().getText();
    String edadStr = vista.getTxtEdad().getText();
    String carrera = vista.getTxtCarrera().getText();
    String promedioStr = vista.getTxtPromedio().getText();

    if (idStr.isEmpty() || nombre.isEmpty() || edadStr.isEmpty()
            || carrera.isEmpty() || promedioStr.isEmpty()) {
        throw new RuntimeException("Complete todos los campos obligatorios");
    }

    int id;
    int edad;
    double promedio;

    try {
        id = Integer.parseInt(idStr);
        edad = Integer.parseInt(edadStr);
        promedio = Double.parseDouble(promedioStr);
    } catch (NumberFormatException e) {
        throw new RuntimeException("ID, Edad y Promedio deben ser numéricos");
    }

    if (id <= 0) {
        throw new RuntimeException("El ID debe ser mayor a 0");
    }

    if (edad <= 0) {
        throw new RuntimeException("La edad debe ser mayor a 0");
    }

    if (promedio < 0 || promedio > 10) {
        throw new RuntimeException("El promedio debe estar entre 0 y 10");
    }

    EstadoAcademico estado = vista.getCbEstado().getValue();
    String tipo = vista.getCbTipo().getValue();

    // ===============================
    // BECADO
    // ===============================

    if ("Becado".equals(tipo)) {

        String porcentajeStr = vista.getTxtPorcentaje().getText();

        if (porcentajeStr.isEmpty()) {
            throw new RuntimeException("Ingrese el porcentaje de beca");
        }

        double porcentaje;

        try {
            porcentaje = Double.parseDouble(porcentajeStr);
        } catch (NumberFormatException e) {
            throw new RuntimeException("El porcentaje debe ser numérico");
        }

        if (porcentaje < 0 || porcentaje > 100) {
            throw new RuntimeException("El porcentaje debe estar entre 0 y 100");
        }

        TipoBeca tipoBeca = vista.getCbBeca().getValue();

        return new EstudianteBecado(
                id, nombre, edad,
                carrera, promedio,
                estado,
                porcentaje, tipoBeca
        );
    }

    // ===============================
    // AYUDANTE
    // ===============================

    if ("Ayudante".equals(tipo)) {

        String materia = vista.getTxtMateria().getText();
        String horasStr = vista.getTxtHoras().getText();
        String valorHoraStr = vista.getTxtValorHora().getText();

        if (materia.isEmpty() || horasStr.isEmpty() || valorHoraStr.isEmpty()) {
            throw new RuntimeException("Complete todos los campos de Ayudante");
        }

        int horas;
        double valorHora;

        try {
            horas = Integer.parseInt(horasStr);
            valorHora = Double.parseDouble(valorHoraStr);
        } catch (NumberFormatException e) {
            throw new RuntimeException("Horas y Valor Hora deben ser numéricos");
        }

        if (horas <= 0) {
            throw new RuntimeException("Las horas deben ser mayores a 0");
        }

        if (valorHora <= 0) {
            throw new RuntimeException("El valor hora debe ser mayor a 0");
        }

        return new EstudianteAyudante(
                id, nombre, edad,
                carrera, promedio,
                estado,
                materia, horas, valorHora
        );
    }

    // ===============================
    // ESTUDIANTE NORMAL
    // ===============================

    return new Estudiante(
            id, nombre, edad,
            carrera, promedio,
            estado
    );
}

    private void actualizarTabla() {
        vistaTabla.actualizarTabla(gestor.getLista());
    }

    private void mostrarAlerta(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setContentText(mensaje);
        alert.show();
    }
    
}