package JavaFX;

import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;

public class VistaLayout {

    private HBox root;

    public VistaLayout(VistaFormulario vistaFormulario,
                       VistaTabla vistaTabla) {

        ScrollPane scroll = new ScrollPane(vistaFormulario.getRoot());
        scroll.setFitToWidth(true);
        scroll.setPrefWidth(350);

        root = new HBox(10,
                scroll,
                vistaTabla.getTabla()
        );

        root.setStyle("-fx-padding: 15;");
    }

    public HBox getRoot() {
        return root;
    }
}