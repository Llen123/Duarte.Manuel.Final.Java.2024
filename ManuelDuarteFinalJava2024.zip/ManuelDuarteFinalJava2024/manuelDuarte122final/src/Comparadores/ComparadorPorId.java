/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Comparadores;

/**
 *
 * @author llen0
 */

import PersonaClases.Persona;
import java.util.Comparator;

public class ComparadorPorId implements Comparator<Persona> {

    @Override
    public int compare(Persona p1, Persona p2) {
        return Integer.compare(p1.getId(), p2.getId());
    }
}

