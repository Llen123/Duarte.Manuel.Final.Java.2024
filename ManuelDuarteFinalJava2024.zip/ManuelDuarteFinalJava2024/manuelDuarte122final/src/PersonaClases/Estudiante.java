/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PersonaClases;

import enums.EstadoAcademico;
import excepciones.EstadoInvalidoException;

/**
 *
 * @author llen0
 */
public class Estudiante extends Persona{

    private String carrera;
    private double promedio;
    private EstadoAcademico estadoAcademico;

    // Constructor completo
    public Estudiante(int id, String nombre, int edad,
                      String carrera, double promedio,
                      EstadoAcademico estadoAcademico) {
        super(id, nombre, edad);
        this.carrera = carrera;
        this.promedio = promedio;
        this.estadoAcademico = estadoAcademico;
    }

    // Constructor con un parámetro menos
    public Estudiante(int id, String nombre, int edad,
                      String carrera, double promedio) {
        this(id, nombre, edad, carrera, promedio, EstadoAcademico.REGULAR);
    }

    // Constructor vacío
    public Estudiante() {
        this.estadoAcademico = EstadoAcademico.REGULAR;
    }

    @Override
    public String mostrarInformacion() {
        return "ID: " + id +
               " | Nombre: " + nombre +
               " | Edad: " + edad +
               " | Carrera: " + carrera +
               " | Promedio: " + promedio +
               " | Estado: " + estadoAcademico;
    }

    // Getters y Setters
    public String getCarrera() { return carrera; }
    public double getPromedio() { return promedio; }
    public EstadoAcademico getEstadoAcademico() { return estadoAcademico; }

    public void setCarrera(String carrera) { this.carrera = carrera; }
    public void setPromedio(double promedio) { this.promedio = promedio; }
    public void setEstadoAcademico(EstadoAcademico estadoAcademico) {
        this.estadoAcademico = estadoAcademico;
    }
    
    public void cambiarEstado(EstadoAcademico nuevoEstado) {

    if (nuevoEstado == null) {
        throw new EstadoInvalidoException("El estado académico no puede ser null");
    }

    if (this.estadoAcademico == EstadoAcademico.EGRESADO) {
        throw new EstadoInvalidoException(
                "No se puede modificar el estado de un estudiante egresado");
    }

    this.estadoAcademico = nuevoEstado;
}


}
