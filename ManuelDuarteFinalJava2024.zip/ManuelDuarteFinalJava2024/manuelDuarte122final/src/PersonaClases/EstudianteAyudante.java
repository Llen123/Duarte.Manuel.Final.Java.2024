/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PersonaClases;

import interfaces.Remunerado;
import enums.EstadoAcademico;

/**
 *
 * @author llen0
 */
public class EstudianteAyudante extends Estudiante implements Remunerado {

    private String materiaAsignada;
    private int horasSemanales;
    private double valorHora;

    // Constructor completo
    public EstudianteAyudante(int id, String nombre, int edad,
                               String carrera, double promedio,
                               EstadoAcademico estadoAcademico,
                               String materiaAsignada, int horasSemanales,
                               double valorHora) {
        super(id, nombre, edad, carrera, promedio, estadoAcademico);
        this.materiaAsignada = materiaAsignada;
        this.horasSemanales = horasSemanales;
        this.valorHora = valorHora;
    }

    // Constructor con un parámetro menos
    public EstudianteAyudante(int id, String nombre, int edad,
                               String carrera, double promedio,
                               String materiaAsignada) {
        super(id, nombre, edad, carrera, promedio);
        this.materiaAsignada = materiaAsignada;
        this.horasSemanales = 5;
        this.valorHora = 1000;
    }

    // Constructor vacío
    public EstudianteAyudante() {
        this.valorHora = 1000;
    }

    @Override
    public double calcularPago() {
        return horasSemanales * valorHora;
    }

    @Override
    public void actualizarPago(double nuevoValor) {
        this.valorHora = nuevoValor;
    }

    @Override
    public String mostrarInformacion() {
        return super.mostrarInformacion() +
               " | Ayudante de: " + materiaAsignada +
               " | Horas: " + horasSemanales +
               " | Pago semanal: $" + calcularPago();
    }

    public String getMateriaAsignada() {return materiaAsignada;}
    public int getHorasSemanales() {return horasSemanales;}
    public double getValorHora() {return valorHora;}
    
}

