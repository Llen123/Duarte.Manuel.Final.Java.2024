/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PersonaClases;

/**
 *
 * @author llen0
 */

import java.io.Serializable;

public abstract class Persona implements Comparable<Persona>, Serializable  {

    protected int id;
    protected String nombre;
    protected int edad;

    // Constructor completo
    public Persona(int id, String nombre, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
    }

    // Constructor con un parámetro menos
    public Persona(int id, String nombre) {
        this(id, nombre, 18); // edad por defecto
    }

    // Constructor vacío
    public Persona() {
    }

    // Métodos comunes
    public void cumplirAños() {
        this.edad++;
    }

    public boolean esMayorDeEdad() {
        return this.edad >= 18;
    }

    public abstract String mostrarInformacion();

    // Getters y Setters
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public int getEdad() { return edad; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setEdad(int edad) { this.edad = edad; }
    
    @Override
    public int compareTo(Persona otra) {
        return Integer.compare(this.getId(), otra.getId());
    }

}
