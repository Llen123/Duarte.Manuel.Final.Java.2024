/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PersonaClases;

import PersonaClases.Estudiante;
import enums.EstadoAcademico;
import enums.TipoBeca;

/**
 *
 * @author llen0
 */
public class EstudianteBecado extends Estudiante {

    private double porcentajeBeca;
    private TipoBeca tipoBeca;

    // Constructor completo
    public EstudianteBecado(int id, String nombre, int edad,
                             String carrera, double promedio,
                             EstadoAcademico estadoAcademico,
                             double porcentajeBeca, TipoBeca tipoBeca) {
        super(id, nombre, edad, carrera, promedio, estadoAcademico);
        this.porcentajeBeca = porcentajeBeca;
        this.tipoBeca = tipoBeca;
    }

    // Constructor con un parámetro menos
    public EstudianteBecado(int id, String nombre, int edad,
                             String carrera, double promedio,
                             double porcentajeBeca) {
        super(id, nombre, edad, carrera, promedio);
        this.porcentajeBeca = porcentajeBeca;
        this.tipoBeca = TipoBeca.ACADEMICA;
    }

    // Constructor vacío
    public EstudianteBecado() {
        this.tipoBeca = TipoBeca.ACADEMICA;
    }

    @Override
    public String mostrarInformacion() {
        return super.mostrarInformacion() +
               " | Beca: " + porcentajeBeca + "%" +
               " | Tipo: " + tipoBeca;
    }

    public double getPorcentajeBeca() { return porcentajeBeca; }
    public TipoBeca getTipoBeca() { return tipoBeca; }

    public void setPorcentajeBeca(double porcentajeBeca) {
        this.porcentajeBeca = porcentajeBeca;
    }

    public void setTipoBeca(TipoBeca tipoBeca) {
        this.tipoBeca = tipoBeca;
    }
}

